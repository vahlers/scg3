var struct_light =
[
    [ "ambient", "d7/d61/struct_light.html#afde8644f2cb008b9ad5aed4869134e80", null ],
    [ "diffuse", "d7/d61/struct_light.html#a15f8af5aaed0feab29b201c741c5c55b", null ],
    [ "halfVector", "d7/d61/struct_light.html#a77ece5ce70af36556ac00ca2239d208d", null ],
    [ "position", "d7/d61/struct_light.html#a3672ec6941670363f20b995109f7f6ad", null ],
    [ "specular", "d7/d61/struct_light.html#a5485f62aa74eb8cbfd0bb0f382486e05", null ],
    [ "spotCosCutoff", "d7/d61/struct_light.html#a4283708f2fd82b0fd33eeaef9ad93da5", null ],
    [ "spotDirection", "d7/d61/struct_light.html#ad06f806524c6192358e569cbf722da7e", null ],
    [ "spotExponent", "d7/d61/struct_light.html#aebb5a2db661b6807dbbb97c2255cbcbe", null ]
];