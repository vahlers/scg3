var structscg_1_1_o_g_l_config =
[
    [ "OGLConfig", "d7/d72/structscg_1_1_o_g_l_config.html#ab426b0e51224e43f75530c8361f85cd2", null ],
    [ "OGLConfig", "d7/d72/structscg_1_1_o_g_l_config.html#a8c81983260c3e8332aefc166ca25a4d6", null ],
    [ "clearColor", "d7/d72/structscg_1_1_o_g_l_config.html#a828b316f88416d32e6f06e1e6d3875ec", null ],
    [ "forwardCompatible", "d7/d72/structscg_1_1_o_g_l_config.html#a8beef0dbe4f408fe403df99f83624ad4", null ],
    [ "profile", "d7/d72/structscg_1_1_o_g_l_config.html#aaa61e58a03eb5d083dae14cfcd530016", null ],
    [ "versionMajor", "d7/d72/structscg_1_1_o_g_l_config.html#a72e3f62b8bdbdcfb3c88be2632ea0d39", null ],
    [ "versionMinor", "d7/d72/structscg_1_1_o_g_l_config.html#aaba86ee72ad2ef9a848c2a6c919018c6", null ]
];