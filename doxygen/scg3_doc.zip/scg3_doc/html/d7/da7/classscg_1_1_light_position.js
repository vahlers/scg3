var classscg_1_1_light_position =
[
    [ "LightPosition", "d7/da7/classscg_1_1_light_position.html#a00266749ab488107f6d053bace73f44c", null ],
    [ "~LightPosition", "d7/da7/classscg_1_1_light_position.html#a536de2951318188d4a528649a4a3d3da", null ],
    [ "accept", "d7/da7/classscg_1_1_light_position.html#a090d61ff7180895b32e20351a797b53d", null ],
    [ "create", "d7/da7/classscg_1_1_light_position.html#a9c1d8988abdbe89e62b2f509b1e933e3", null ],
    [ "getLight", "d7/da7/classscg_1_1_light_position.html#a0686b7d282dab407d079315f5b4a2d8b", null ],
    [ "setLight", "d7/da7/classscg_1_1_light_position.html#ae9b639ed6769d09067f1579a2b509947", null ],
    [ "light_", "d7/da7/classscg_1_1_light_position.html#adae5db8f85ac197e4a18469e30bf5c9b", null ]
];