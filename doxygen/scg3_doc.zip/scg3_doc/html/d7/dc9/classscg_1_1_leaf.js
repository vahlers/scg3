var classscg_1_1_leaf =
[
    [ "Leaf", "d7/dc9/classscg_1_1_leaf.html#a16a325262f438fd86db27e3693fad229", null ],
    [ "~Leaf", "d7/dc9/classscg_1_1_leaf.html#a1f348a49d0f96f9cfb9cd2acf94d0580", null ],
    [ "traverse", "d7/dc9/classscg_1_1_leaf.html#a21633fd7620a705b4e11e01d6e02f4a5", null ]
];