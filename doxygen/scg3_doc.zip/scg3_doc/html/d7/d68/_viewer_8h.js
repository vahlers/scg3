var _viewer_8h =
[
    [ "OGLConfig", "d7/d72/structscg_1_1_o_g_l_config.html", "d7/d72/structscg_1_1_o_g_l_config" ],
    [ "FrameBufferSize", "db/d02/structscg_1_1_frame_buffer_size.html", "db/d02/structscg_1_1_frame_buffer_size" ],
    [ "Viewer", "d1/db0/classscg_1_1_viewer.html", "d1/db0/classscg_1_1_viewer" ],
    [ "OGLProfile", "d7/d68/_viewer_8h.html#a8fdd17cb9047a77015a4e6641de3136f", [
      [ "NONE", "d7/d68/_viewer_8h.html#a8fdd17cb9047a77015a4e6641de3136fab50339a10e1de285ac99d4c3990b8693", null ],
      [ "CORE", "d7/d68/_viewer_8h.html#a8fdd17cb9047a77015a4e6641de3136fac5d5df976f196200d1900b2b51827dbb", null ],
      [ "COMPATIBILITY", "d7/d68/_viewer_8h.html#a8fdd17cb9047a77015a4e6641de3136faf4b4ae84da5517a2acc77588678044ff", null ]
    ] ]
];