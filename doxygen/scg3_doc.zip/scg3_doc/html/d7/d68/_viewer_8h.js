var _viewer_8h =
[
    [ "OGLConfig", "d7/d72/structscg_1_1_o_g_l_config.html", "d7/d72/structscg_1_1_o_g_l_config" ],
    [ "FrameBufferSize", "db/d02/structscg_1_1_frame_buffer_size.html", "db/d02/structscg_1_1_frame_buffer_size" ],
    [ "Viewer", "d1/db0/classscg_1_1_viewer.html", "d1/db0/classscg_1_1_viewer" ],
    [ "OGLProfile", "d7/d68/_viewer_8h.html#a6c2266d6c86cbeff8722c82b976a09d5", [
      [ "NONE", "d7/d68/_viewer_8h.html#a6c2266d6c86cbeff8722c82b976a09d5a61278d1a5bc27f2bb3535d57abea2849", null ],
      [ "CORE", "d7/d68/_viewer_8h.html#a6c2266d6c86cbeff8722c82b976a09d5acff19757eeeb1f1c0bc1fcc7e8d20d9a", null ],
      [ "COMPATIBILITY", "d7/d68/_viewer_8h.html#a6c2266d6c86cbeff8722c82b976a09d5a34726bb0365ff6d4342749a26f8b79f6", null ]
    ] ]
];