var annotated =
[
    [ "scg", "d7/d60/namespacescg.html", "d7/d60/namespacescg" ],
    [ "Light", "d7/d61/struct_light.html", "d7/d61/struct_light" ],
    [ "Material", "d3/d0a/struct_material.html", "d3/d0a/struct_material" ]
];