var files =
[
    [ "shaders", "dir_95c752037a97b41030102703686a0a90.html", "dir_95c752037a97b41030102703686a0a90" ],
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ],
    [ "src_ext", "dir_d39e4e7c1e0fb759190ad75af8db9848.html", "dir_d39e4e7c1e0fb759190ad75af8db9848" ],
    [ "scg3.h", "d4/d61/scg3_8h.html", null ],
    [ "scg3_ext.h", "d0/d5b/scg3__ext_8h.html", null ]
];