var structscg_1_1_frame_buffer_size =
[
    [ "FrameBufferSize", "db/d02/structscg_1_1_frame_buffer_size.html#a819fd7e5bac1a781b5fa74bb71eeaacb", null ],
    [ "alphabits", "db/d02/structscg_1_1_frame_buffer_size.html#ad2151b06b5ebe8b11c8c149d7724a1d9", null ],
    [ "bluebits", "db/d02/structscg_1_1_frame_buffer_size.html#a7b60da08fec197b788cbb30badb19444", null ],
    [ "depthbits", "db/d02/structscg_1_1_frame_buffer_size.html#ab2e6f53ab7d2a477aca9d6c5d25b898d", null ],
    [ "greenbits", "db/d02/structscg_1_1_frame_buffer_size.html#a806e187d736e2af2f144b2fa891b8b62", null ],
    [ "redbits", "db/d02/structscg_1_1_frame_buffer_size.html#ab906deb95b096665b846c38db8c1cf02", null ],
    [ "stencilbits", "db/d02/structscg_1_1_frame_buffer_size.html#a2778eaf825c6c75f61579cf158512a57", null ]
];