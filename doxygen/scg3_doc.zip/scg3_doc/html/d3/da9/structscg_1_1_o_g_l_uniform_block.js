var structscg_1_1_o_g_l_uniform_block =
[
    [ "bindingPoint", "d3/da9/structscg_1_1_o_g_l_uniform_block.html#ab9b5f5867af490550d7535ed44bf961f", null ],
    [ "name", "d3/da9/structscg_1_1_o_g_l_uniform_block.html#a8af7497bc84a8c3118cd1955ac571821", null ]
];