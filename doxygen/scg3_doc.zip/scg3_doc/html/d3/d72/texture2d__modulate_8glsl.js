var texture2d__modulate_8glsl =
[
    [ "applyTexture", "d3/d72/texture2d__modulate_8glsl.html#accc539b73835065cb0787a4a4d785ea9", null ],
    [ "texture0", "d3/d72/texture2d__modulate_8glsl.html#a48607515de807c3ed2870629924281e3", null ]
];