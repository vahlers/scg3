var struct_material =
[
    [ "ambient", "d3/d0a/struct_material.html#addd1d1e5d189085f2a6a7b8e044a74a0", null ],
    [ "diffuse", "d3/d0a/struct_material.html#ad8a3d69cb6bb946fa1eea6455167006e", null ],
    [ "emission", "d3/d0a/struct_material.html#a7d341106738b136210e66f281af6e988", null ],
    [ "shininess", "d3/d0a/struct_material.html#a9dc184c883ec135ace28c1917af3fe84", null ],
    [ "specular", "d3/d0a/struct_material.html#ace47fac127862456f8d0d7f1a51a4e75", null ]
];