var classscg_1_1_view_state =
[
    [ "ViewState", "d3/dde/classscg_1_1_view_state.html#ada668a8f250fb06480efd2a49b4f027c", null ],
    [ "~ViewState", "d3/dde/classscg_1_1_view_state.html#a1553b60163b6de7c7f7f20e19faede65", null ],
    [ "getFrameRate", "d3/dde/classscg_1_1_view_state.html#a41d1132112c0676ad9d1c476118f859e", null ],
    [ "getWindow", "d3/dde/classscg_1_1_view_state.html#acc913a6c69b3e08538d31ab60cc0022c", null ],
    [ "isAnimationLocked", "d3/dde/classscg_1_1_view_state.html#a34db9ffff8218a194b23fabdd9c71987", null ],
    [ "isFrameRateOutput", "d3/dde/classscg_1_1_view_state.html#a257bd6946c77a43f9e76254ee65f9ea0", null ],
    [ "isMouseCursorVisible", "d3/dde/classscg_1_1_view_state.html#a54cc29f87c425c6a2f20d414e6ea1d45", null ],
    [ "setAnimationLocked", "d3/dde/classscg_1_1_view_state.html#a4c9b3d72cf54f3559d219a6dcc21d20b", null ],
    [ "setFrameRateInterval", "d3/dde/classscg_1_1_view_state.html#ae5a34c31e6387080988c31da07b71440", null ],
    [ "setFrameRateOutput", "d3/dde/classscg_1_1_view_state.html#afab0c0eafcc5385e72c78b6870e5ec11", null ],
    [ "setMouseCursorVisible", "d3/dde/classscg_1_1_view_state.html#a814fec4d2a33925adaafed4b1108bc81", null ],
    [ "setWindow", "d3/dde/classscg_1_1_view_state.html#af922598d8073db06bc2fb0554d2a2dbd", null ],
    [ "updateFrameRate", "d3/dde/classscg_1_1_view_state.html#a2bd82f6344ace35281aa35e9b25dc21a", null ],
    [ "frameRate_", "d3/dde/classscg_1_1_view_state.html#abf67051addb697db5767fa12aa35a4b1", null ],
    [ "frameRateInterval_", "d3/dde/classscg_1_1_view_state.html#a14438c9db1890e754a11de04e7554a02", null ],
    [ "isAnimationLocked_", "d3/dde/classscg_1_1_view_state.html#a77fe39d264cf64bea72f92fdfb028a51", null ],
    [ "isFrameRateOutput_", "d3/dde/classscg_1_1_view_state.html#a2332509d09fd54869c47dca8b481a693", null ],
    [ "isMouseCursorVisible_", "d3/dde/classscg_1_1_view_state.html#ab2718cda4595afd082b87a555f9d143b", null ],
    [ "window_", "d3/dde/classscg_1_1_view_state.html#a793e12b7e3c858452b8389e41208699d", null ]
];