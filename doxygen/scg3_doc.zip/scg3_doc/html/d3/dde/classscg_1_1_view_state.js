var classscg_1_1_view_state =
[
    [ "ViewState", "d3/dde/classscg_1_1_view_state.html#ada668a8f250fb06480efd2a49b4f027c", null ],
    [ "~ViewState", "d3/dde/classscg_1_1_view_state.html#a1553b60163b6de7c7f7f20e19faede65", null ],
    [ "getFrameRate", "d3/dde/classscg_1_1_view_state.html#a9f2ee592c9a0c36552e87682e90e1c28", null ],
    [ "getWindow", "d3/dde/classscg_1_1_view_state.html#a05fe8bc4a20f9978da6cc9f391040d1a", null ],
    [ "isAnimationLocked", "d3/dde/classscg_1_1_view_state.html#a6f292b263ec50c4fd37b579c52af3c0c", null ],
    [ "isFrameRateOutput", "d3/dde/classscg_1_1_view_state.html#aaefc875431d69a5a45fb751c939c119a", null ],
    [ "isMouseCursorVisible", "d3/dde/classscg_1_1_view_state.html#a927f6b459dc3e0e9e0dcfabe8b345d4f", null ],
    [ "setAnimationLocked", "d3/dde/classscg_1_1_view_state.html#a4c9b3d72cf54f3559d219a6dcc21d20b", null ],
    [ "setFrameRateInterval", "d3/dde/classscg_1_1_view_state.html#ae5a34c31e6387080988c31da07b71440", null ],
    [ "setFrameRateOutput", "d3/dde/classscg_1_1_view_state.html#afab0c0eafcc5385e72c78b6870e5ec11", null ],
    [ "setMouseCursorVisible", "d3/dde/classscg_1_1_view_state.html#a814fec4d2a33925adaafed4b1108bc81", null ],
    [ "setWindow", "d3/dde/classscg_1_1_view_state.html#af922598d8073db06bc2fb0554d2a2dbd", null ],
    [ "updateFrameRate", "d3/dde/classscg_1_1_view_state.html#a2bd82f6344ace35281aa35e9b25dc21a", null ],
    [ "frameRate_", "d3/dde/classscg_1_1_view_state.html#abf67051addb697db5767fa12aa35a4b1", null ],
    [ "frameRateInterval_", "d3/dde/classscg_1_1_view_state.html#a14438c9db1890e754a11de04e7554a02", null ],
    [ "isAnimationLocked_", "d3/dde/classscg_1_1_view_state.html#a77fe39d264cf64bea72f92fdfb028a51", null ],
    [ "isFrameRateOutput_", "d3/dde/classscg_1_1_view_state.html#a2332509d09fd54869c47dca8b481a693", null ],
    [ "isMouseCursorVisible_", "d3/dde/classscg_1_1_view_state.html#ab2718cda4595afd082b87a555f9d143b", null ],
    [ "window_", "d3/dde/classscg_1_1_view_state.html#a793e12b7e3c858452b8389e41208699d", null ]
];