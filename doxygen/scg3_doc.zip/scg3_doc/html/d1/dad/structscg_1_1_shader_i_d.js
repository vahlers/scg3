var structscg_1_1_shader_i_d =
[
    [ "ShaderID", "d1/dad/structscg_1_1_shader_i_d.html#aeb618abfd1da31755cd8691b538c926c", null ],
    [ "ShaderID", "d1/dad/structscg_1_1_shader_i_d.html#a6cf7069ed37d2414e190e1d3073b55b9", null ],
    [ "name", "d1/dad/structscg_1_1_shader_i_d.html#a3ee4f2d25bc558d498f99399181f5b93", null ],
    [ "shader", "d1/dad/structscg_1_1_shader_i_d.html#a52c09d4df411c3dbaf31155430da360e", null ]
];