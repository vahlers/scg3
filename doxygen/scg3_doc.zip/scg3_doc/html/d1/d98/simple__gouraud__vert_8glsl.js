var simple__gouraud__vert_8glsl =
[
    [ "Light", "d7/d61/struct_light.html", "d7/d61/struct_light" ],
    [ "Material", "d3/d0a/struct_material.html", "d3/d0a/struct_material" ],
    [ "applyLighting", "d1/d98/simple__gouraud__vert_8glsl.html#a84fe1f6b75c539f68fd811da7d7a45b2", null ],
    [ "layout", "d1/d98/simple__gouraud__vert_8glsl.html#a50f033ca1c07e51e1917c7b9eff9acaf", null ],
    [ "main", "d1/d98/simple__gouraud__vert_8glsl.html#acdef7a1fd863a6d3770c1268cb06add3", null ],
    [ "color", "d1/d98/simple__gouraud__vert_8glsl.html#a823dde5d00878f2add059e4a467537c5", null ],
    [ "globalAmbientLight", "d1/d98/simple__gouraud__vert_8glsl.html#aa7bbb16f764a18c19e8b541d163e0745", null ],
    [ "MAX_NUMBER_OF_LIGHTS", "d1/d98/simple__gouraud__vert_8glsl.html#a37b1f22d3695f43409926ca1c960f1fe", null ],
    [ "modelViewMatrix", "d1/d98/simple__gouraud__vert_8glsl.html#a5e6969c9c6ce1443f7dc50222103c308", null ],
    [ "mvpMatrix", "d1/d98/simple__gouraud__vert_8glsl.html#a8869ed6f651419c34be26203871e07fd", null ],
    [ "nLights", "d1/d98/simple__gouraud__vert_8glsl.html#a322d434fbb6f95c69bb1bdb8dfc18faa", null ],
    [ "normalMatrix", "d1/d98/simple__gouraud__vert_8glsl.html#a613da608ed25b0db6632175b0e98986d", null ],
    [ "projectionMatrix", "d1/d98/simple__gouraud__vert_8glsl.html#a4afdc86da019756998ce4bf61489c314", null ],
    [ "vNormal", "d1/d98/simple__gouraud__vert_8glsl.html#ad626ff2abc6d629c4af4c7f2da13136a", null ],
    [ "vVertex", "d1/d98/simple__gouraud__vert_8glsl.html#a398ee103f758e459a20ce7c2e0b513dd", null ]
];