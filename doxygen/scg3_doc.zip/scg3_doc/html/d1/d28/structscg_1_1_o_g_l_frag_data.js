var structscg_1_1_o_g_l_frag_data =
[
    [ "location", "d1/d28/structscg_1_1_o_g_l_frag_data.html#a1d8f947f22fda2596400672fbdd4cb96", null ],
    [ "name", "d1/d28/structscg_1_1_o_g_l_frag_data.html#a05960c994cac21364741f7737da1bbad", null ]
];