var dir_b79d5b58257f5086cb1beea90389740d =
[
    [ "Animation.h", "dc/d8b/_animation_8h.html", [
      [ "Animation", "d2/df5/classscg_1_1_animation.html", "d2/df5/classscg_1_1_animation" ]
    ] ],
    [ "BumpMapCore.h", "d6/d52/_bump_map_core_8h.html", [
      [ "BumpMapCore", "db/d63/classscg_1_1_bump_map_core.html", "db/d63/classscg_1_1_bump_map_core" ]
    ] ],
    [ "Camera.h", "d5/d91/_camera_8h.html", [
      [ "Camera", "d4/dc9/classscg_1_1_camera.html", "d4/dc9/classscg_1_1_camera" ]
    ] ],
    [ "CameraController.h", "d0/ddc/_camera_controller_8h.html", [
      [ "CameraController", "de/d6a/classscg_1_1_camera_controller.html", "de/d6a/classscg_1_1_camera_controller" ]
    ] ],
    [ "ColorCore.h", "de/df9/_color_core_8h.html", [
      [ "ColorCore", "d9/dc2/classscg_1_1_color_core.html", "d9/dc2/classscg_1_1_color_core" ]
    ] ],
    [ "Composite.h", "d4/d6d/_composite_8h.html", [
      [ "Composite", "da/d38/classscg_1_1_composite.html", "da/d38/classscg_1_1_composite" ]
    ] ],
    [ "Controller.h", "d2/d94/_controller_8h.html", [
      [ "Controller", "de/de4/classscg_1_1_controller.html", "de/de4/classscg_1_1_controller" ]
    ] ],
    [ "Core.h", "d4/d09/_core_8h.html", [
      [ "Core", "d0/d79/classscg_1_1_core.html", "d0/d79/classscg_1_1_core" ]
    ] ],
    [ "CubeMapCore.h", "d1/d6d/_cube_map_core_8h.html", [
      [ "CubeMapCore", "d9/d5b/classscg_1_1_cube_map_core.html", "d9/d5b/classscg_1_1_cube_map_core" ]
    ] ],
    [ "GeometryCore.h", "d2/d02/_geometry_core_8h.html", "d2/d02/_geometry_core_8h" ],
    [ "GeometryCoreFactory.h", "d1/dd4/_geometry_core_factory_8h.html", [
      [ "GeometryCoreFactory", "dc/dfb/classscg_1_1_geometry_core_factory.html", "dc/dfb/classscg_1_1_geometry_core_factory" ],
      [ "FaceEntry", "d4/dee/structscg_1_1_geometry_core_factory_1_1_face_entry.html", "d4/dee/structscg_1_1_geometry_core_factory_1_1_face_entry" ],
      [ "Face", "d0/d68/structscg_1_1_geometry_core_factory_1_1_face.html", "d0/d68/structscg_1_1_geometry_core_factory_1_1_face" ],
      [ "OBJModel", "df/d77/structscg_1_1_geometry_core_factory_1_1_o_b_j_model.html", "df/d77/structscg_1_1_geometry_core_factory_1_1_o_b_j_model" ]
    ] ],
    [ "Group.h", "d7/dc4/_group_8h.html", [
      [ "Group", "dd/d6a/classscg_1_1_group.html", "dd/d6a/classscg_1_1_group" ]
    ] ],
    [ "InfoTraverser.h", "d9/d3a/_info_traverser_8h.html", [
      [ "InfoTraverser", "db/d76/classscg_1_1_info_traverser.html", "db/d76/classscg_1_1_info_traverser" ]
    ] ],
    [ "KeyboardController.h", "d4/dd4/_keyboard_controller_8h.html", [
      [ "KeyboardController", "dd/d66/classscg_1_1_keyboard_controller.html", "dd/d66/classscg_1_1_keyboard_controller" ]
    ] ],
    [ "Leaf.h", "d4/dfd/_leaf_8h.html", [
      [ "Leaf", "d7/dc9/classscg_1_1_leaf.html", "d7/dc9/classscg_1_1_leaf" ]
    ] ],
    [ "Light.h", "d2/d46/_light_8h.html", [
      [ "Light", "da/d81/classscg_1_1_light.html", "da/d81/classscg_1_1_light" ]
    ] ],
    [ "LightPosition.h", "d2/db4/_light_position_8h.html", [
      [ "LightPosition", "d7/da7/classscg_1_1_light_position.html", "d7/da7/classscg_1_1_light_position" ]
    ] ],
    [ "MaterialCore.h", "db/d01/_material_core_8h.html", [
      [ "MaterialCore", "db/d10/classscg_1_1_material_core.html", "db/d10/classscg_1_1_material_core" ]
    ] ],
    [ "MouseController.h", "d4/d18/_mouse_controller_8h.html", [
      [ "MouseController", "da/d9a/classscg_1_1_mouse_controller.html", "da/d9a/classscg_1_1_mouse_controller" ]
    ] ],
    [ "Node.h", "d1/d02/_node_8h.html", [
      [ "Node", "d4/dc7/classscg_1_1_node.html", "d4/dc7/classscg_1_1_node" ]
    ] ],
    [ "OrthographicCamera.h", "d5/dea/_orthographic_camera_8h.html", [
      [ "OrthographicCamera", "d0/d02/classscg_1_1_orthographic_camera.html", "d0/d02/classscg_1_1_orthographic_camera" ]
    ] ],
    [ "PerspectiveCamera.h", "df/db1/_perspective_camera_8h.html", [
      [ "PerspectiveCamera", "d2/d30/classscg_1_1_perspective_camera.html", "d2/d30/classscg_1_1_perspective_camera" ]
    ] ],
    [ "PreTraverser.h", "d3/d12/_pre_traverser_8h.html", [
      [ "PreTraverser", "d6/da7/classscg_1_1_pre_traverser.html", "d6/da7/classscg_1_1_pre_traverser" ]
    ] ],
    [ "Renderer.h", "d3/da0/_renderer_8h.html", [
      [ "Renderer", "d8/dcf/classscg_1_1_renderer.html", "d8/dcf/classscg_1_1_renderer" ]
    ] ],
    [ "RenderState.h", "d4/dc3/_render_state_8h.html", [
      [ "MatrixStack", "d4/dab/classscg_1_1_matrix_stack.html", "d4/dab/classscg_1_1_matrix_stack" ],
      [ "RenderState", "db/dfa/classscg_1_1_render_state.html", "db/dfa/classscg_1_1_render_state" ]
    ] ],
    [ "RenderTraverser.h", "df/d28/_render_traverser_8h.html", [
      [ "RenderTraverser", "d7/df6/classscg_1_1_render_traverser.html", "d7/df6/classscg_1_1_render_traverser" ]
    ] ],
    [ "scg_doxygen_stub.h", "d9/d3c/scg__doxygen__stub_8h.html", "d9/d3c/scg__doxygen__stub_8h" ],
    [ "scg_glew.h", "d6/d90/scg__glew_8h.html", null ],
    [ "scg_glm.h", "d2/d56/scg__glm_8h.html", null ],
    [ "scg_internals.cpp", "de/d4d/scg__internals_8cpp.html", null ],
    [ "scg_internals.h", "d9/de0/scg__internals_8h.html", "d9/de0/scg__internals_8h" ],
    [ "scg_stb_image.h", "d0/d4f/scg__stb__image_8h.html", "d0/d4f/scg__stb__image_8h" ],
    [ "scg_utilities.h", "d7/d0b/scg__utilities_8h.html", "d7/d0b/scg__utilities_8h" ],
    [ "ShaderCore.h", "d9/d13/_shader_core_8h.html", [
      [ "ShaderID", "d1/dad/structscg_1_1_shader_i_d.html", "d1/dad/structscg_1_1_shader_i_d" ],
      [ "ShaderCore", "df/de9/classscg_1_1_shader_core.html", "df/de9/classscg_1_1_shader_core" ]
    ] ],
    [ "ShaderCoreFactory.h", "da/dbb/_shader_core_factory_8h.html", [
      [ "ShaderFile", "d2/d8b/structscg_1_1_shader_file.html", "d2/d8b/structscg_1_1_shader_file" ],
      [ "ShaderCoreFactory", "dd/d29/classscg_1_1_shader_core_factory.html", "dd/d29/classscg_1_1_shader_core_factory" ]
    ] ],
    [ "Shape.h", "da/d05/_shape_8h.html", [
      [ "Shape", "d1/d94/classscg_1_1_shape.html", "d1/d94/classscg_1_1_shape" ]
    ] ],
    [ "StandardRenderer.h", "d8/d69/_standard_renderer_8h.html", [
      [ "StandardRenderer", "d5/db3/classscg_1_1_standard_renderer.html", "d5/db3/classscg_1_1_standard_renderer" ]
    ] ],
    [ "Texture2DCore.h", "d3/dd2/_texture2_d_core_8h.html", [
      [ "Texture2DCore", "dc/d19/classscg_1_1_texture2_d_core.html", "dc/d19/classscg_1_1_texture2_d_core" ]
    ] ],
    [ "TextureCore.h", "df/d62/_texture_core_8h.html", [
      [ "TextureCore", "d1/d4f/classscg_1_1_texture_core.html", "d1/d4f/classscg_1_1_texture_core" ]
    ] ],
    [ "TextureCoreFactory.h", "d6/d79/_texture_core_factory_8h.html", [
      [ "TextureCoreFactory", "de/d73/classscg_1_1_texture_core_factory.html", "de/d73/classscg_1_1_texture_core_factory" ]
    ] ],
    [ "TransformAnimation.h", "db/d28/_transform_animation_8h.html", [
      [ "TransformAnimation", "dd/d67/classscg_1_1_transform_animation.html", "dd/d67/classscg_1_1_transform_animation" ]
    ] ],
    [ "Transformation.h", "d3/d21/_transformation_8h.html", [
      [ "Transformation", "d0/d99/classscg_1_1_transformation.html", "d0/d99/classscg_1_1_transformation" ]
    ] ],
    [ "Traverser.h", "de/d46/_traverser_8h.html", [
      [ "Traverser", "dc/d03/classscg_1_1_traverser.html", "dc/d03/classscg_1_1_traverser" ]
    ] ],
    [ "Viewer.h", "d7/d68/_viewer_8h.html", "d7/d68/_viewer_8h" ],
    [ "ViewState.h", "de/d09/_view_state_8h.html", [
      [ "ViewState", "d3/dde/classscg_1_1_view_state.html", "d3/dde/classscg_1_1_view_state" ]
    ] ]
];