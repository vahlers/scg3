var color__frag_8glsl =
[
    [ "main", "d6/d1a/color__frag_8glsl.html#a6288eba0f8e8ad3ab1544ad731eb7667", null ],
    [ "color", "d6/d1a/color__frag_8glsl.html#a42375368d899f08663d5c1c4ce8758f6", null ],
    [ "fragColor", "d6/d1a/color__frag_8glsl.html#a6d8dd0540ed9af35f34cd31b838cacce", null ]
];