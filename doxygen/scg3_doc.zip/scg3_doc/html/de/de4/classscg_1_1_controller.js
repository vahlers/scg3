var classscg_1_1_controller =
[
    [ "Controller", "de/de4/classscg_1_1_controller.html#a5fad42bfbf8dabb3f648767fb459ba4b", null ],
    [ "~Controller", "de/de4/classscg_1_1_controller.html#a5cd6a7713be74836f0c1a69e14035027", null ],
    [ "checkInput", "de/de4/classscg_1_1_controller.html#a2733828121e3b426c8f82d1cccf3a97c", null ]
];