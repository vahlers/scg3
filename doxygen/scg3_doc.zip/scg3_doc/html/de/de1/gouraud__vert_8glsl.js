var gouraud__vert_8glsl =
[
    [ "applyLighting", "de/de1/gouraud__vert_8glsl.html#ae8ca6d4e798b8b07ee4edb4125da1514", null ],
    [ "main", "de/de1/gouraud__vert_8glsl.html#acdef7a1fd863a6d3770c1268cb06add3", null ],
    [ "emissionAmbientDiffuse", "de/de1/gouraud__vert_8glsl.html#abdc8b597c612921668f44ae6378d4500", null ],
    [ "modelViewMatrix", "de/de1/gouraud__vert_8glsl.html#a5e6969c9c6ce1443f7dc50222103c308", null ],
    [ "mvpMatrix", "de/de1/gouraud__vert_8glsl.html#a8869ed6f651419c34be26203871e07fd", null ],
    [ "normalMatrix", "de/de1/gouraud__vert_8glsl.html#a613da608ed25b0db6632175b0e98986d", null ],
    [ "projectionMatrix", "de/de1/gouraud__vert_8glsl.html#a4afdc86da019756998ce4bf61489c314", null ],
    [ "specular", "de/de1/gouraud__vert_8glsl.html#a2131ace5aecb22827848b656852c2c1d", null ],
    [ "texCoord0", "de/de1/gouraud__vert_8glsl.html#a293f101c32ac08f9ed0d0d4031d3e651", null ],
    [ "textureMatrix", "de/de1/gouraud__vert_8glsl.html#a26564c387e5a0a30e571e72e63957c3f", null ],
    [ "vNormal", "de/de1/gouraud__vert_8glsl.html#ad626ff2abc6d629c4af4c7f2da13136a", null ],
    [ "vTexCoord0", "de/de1/gouraud__vert_8glsl.html#a950c791011062cfd2ef5946b40921040", null ],
    [ "vVertex", "de/de1/gouraud__vert_8glsl.html#a398ee103f758e459a20ce7c2e0b513dd", null ]
];