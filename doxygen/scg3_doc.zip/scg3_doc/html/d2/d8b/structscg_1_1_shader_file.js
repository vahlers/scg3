var structscg_1_1_shader_file =
[
    [ "ShaderFile", "d2/d8b/structscg_1_1_shader_file.html#a9f17f6b43d60fbe16b02572e698cd037", null ],
    [ "fileName", "d2/d8b/structscg_1_1_shader_file.html#a58f52673c99ca4e0742cdfeda83694ba", null ],
    [ "shaderType", "d2/d8b/structscg_1_1_shader_file.html#a5c91cd32ff3eaac35f23d01711b117aa", null ]
];