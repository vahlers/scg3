var _geometry_core_8h =
[
    [ "GeometryCore", "d7/d13/classscg_1_1_geometry_core.html", "d7/d13/classscg_1_1_geometry_core" ],
    [ "DrawMode", "d2/d02/_geometry_core_8h.html#a5ed826e864770c5262fc06005b0cc276", [
      [ "ARRAYS", "d2/d02/_geometry_core_8h.html#a5ed826e864770c5262fc06005b0cc276a5342184fa5ab2befe3ec1905ed8726fa", null ],
      [ "ELEMENTS", "d2/d02/_geometry_core_8h.html#a5ed826e864770c5262fc06005b0cc276a2b806d88270761f39ab1ca2dd78f038a", null ]
    ] ]
];