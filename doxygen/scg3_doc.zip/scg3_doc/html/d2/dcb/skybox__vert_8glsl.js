var skybox__vert_8glsl =
[
    [ "main", "d2/dcb/skybox__vert_8glsl.html#acdef7a1fd863a6d3770c1268cb06add3", null ],
    [ "skyboxMatrix", "d2/dcb/skybox__vert_8glsl.html#a9d210956c222f47a6889180a5641ab22", null ],
    [ "texCoord0", "d2/dcb/skybox__vert_8glsl.html#ad467d0856055e306d649b400751a1d37", null ],
    [ "vVertex", "d2/dcb/skybox__vert_8glsl.html#a398ee103f758e459a20ce7c2e0b513dd", null ]
];