var gouraud__frag_8glsl =
[
    [ "applyTexture", "d2/da5/gouraud__frag_8glsl.html#accc539b73835065cb0787a4a4d785ea9", null ],
    [ "main", "d2/da5/gouraud__frag_8glsl.html#a6288eba0f8e8ad3ab1544ad731eb7667", null ],
    [ "colorMatrix", "d2/da5/gouraud__frag_8glsl.html#ac75ede864f85be96eaa94ce0be32ee9f", null ],
    [ "emissionAmbientDiffuse", "d2/da5/gouraud__frag_8glsl.html#a54e7b3b4524c05c9c9361e84829ba55c", null ],
    [ "fragColor", "d2/da5/gouraud__frag_8glsl.html#a6d8dd0540ed9af35f34cd31b838cacce", null ],
    [ "specular", "d2/da5/gouraud__frag_8glsl.html#ae10e95048eacb72ae2e9570b048c5b46", null ],
    [ "texCoord0", "d2/da5/gouraud__frag_8glsl.html#a443df2dc8ae6211af43c10709e5fef1a", null ]
];