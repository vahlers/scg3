var classscg_1_1_perspective_camera =
[
    [ "PerspectiveCamera", "d2/d30/classscg_1_1_perspective_camera.html#a2f998c1ffe08a426542c0f902ef786df", null ],
    [ "~PerspectiveCamera", "d2/d30/classscg_1_1_perspective_camera.html#ab858a6846331fe7ea5ce5f48e3641ba0", null ],
    [ "create", "d2/d30/classscg_1_1_perspective_camera.html#aca48c405eeeb17a13adb9ed83ec8da55", null ],
    [ "init", "d2/d30/classscg_1_1_perspective_camera.html#a21c450834011c57713668c031b0769e4", null ],
    [ "updateProjection", "d2/d30/classscg_1_1_perspective_camera.html#add2814ee38cc957e5b6b128a5c2f14c0", null ],
    [ "far_", "d2/d30/classscg_1_1_perspective_camera.html#ab9177d567ad434ffce0b7f4d63972ecb", null ],
    [ "fovyDeg_", "d2/d30/classscg_1_1_perspective_camera.html#a37cf68c6387e841284652b8f04353c79", null ],
    [ "near_", "d2/d30/classscg_1_1_perspective_camera.html#ac9d08d1434ae8568252c212d604b4027", null ]
];