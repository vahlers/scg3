var phong__frag_8glsl =
[
    [ "applyLighting", "df/dfe/phong__frag_8glsl.html#ae8ca6d4e798b8b07ee4edb4125da1514", null ],
    [ "applyTexture", "df/dfe/phong__frag_8glsl.html#accc539b73835065cb0787a4a4d785ea9", null ],
    [ "main", "df/dfe/phong__frag_8glsl.html#a6288eba0f8e8ad3ab1544ad731eb7667", null ],
    [ "colorMatrix", "df/dfe/phong__frag_8glsl.html#ac75ede864f85be96eaa94ce0be32ee9f", null ],
    [ "ecNormal", "df/dfe/phong__frag_8glsl.html#aa6c8762afe49d7263c858bb0b1837a9d", null ],
    [ "ecVertex", "df/dfe/phong__frag_8glsl.html#af2dfd05001002260ff6c4f7e5889e3a6", null ],
    [ "fragColor", "df/dfe/phong__frag_8glsl.html#a6d8dd0540ed9af35f34cd31b838cacce", null ],
    [ "texCoord0", "df/dfe/phong__frag_8glsl.html#a443df2dc8ae6211af43c10709e5fef1a", null ]
];