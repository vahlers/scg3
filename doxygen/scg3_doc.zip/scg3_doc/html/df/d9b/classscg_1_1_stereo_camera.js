var classscg_1_1_stereo_camera =
[
    [ "StereoCamera", "df/d9b/classscg_1_1_stereo_camera.html#abc93796fecb70ef82619f605e3c8d15a", null ],
    [ "~StereoCamera", "df/d9b/classscg_1_1_stereo_camera.html#aa522114c5934a08ae4cf67249c964d94", null ],
    [ "create", "df/d9b/classscg_1_1_stereo_camera.html#a644459836a1f3cc7e588f3e7da851a6d", null ],
    [ "getProjection", "df/d9b/classscg_1_1_stereo_camera.html#a5d5c88e77ab86dcbb27c6de5e15ae161", null ],
    [ "getViewTransform", "df/d9b/classscg_1_1_stereo_camera.html#a11db527b357b9c65de4d9ea2fb033421", null ],
    [ "init", "df/d9b/classscg_1_1_stereo_camera.html#a955d0cbbddec750e858e6e5ccb7d65b7", null ],
    [ "initBourke", "df/d9b/classscg_1_1_stereo_camera.html#aa556db92aac7acdaacd2241d349dfbca", null ],
    [ "render", "df/d9b/classscg_1_1_stereo_camera.html#a94b1095d823d9a2de3c575102104bfa9", null ],
    [ "updateProjection", "df/d9b/classscg_1_1_stereo_camera.html#ae155d2e196a8fbae528f9d63baaa57a9", null ],
    [ "eyeFactor_", "df/d9b/classscg_1_1_stereo_camera.html#aca0140809a7538f0c3a901d757d7da46", null ],
    [ "far_", "df/d9b/classscg_1_1_stereo_camera.html#a961cbd053d6b3e19f0c3fca4f2dda47e", null ],
    [ "interOcularHalfDist_", "df/d9b/classscg_1_1_stereo_camera.html#a2664d3baa0d1932606193381b38fc28b", null ],
    [ "near_", "df/d9b/classscg_1_1_stereo_camera.html#a7685c9ebd0118b11bbf1d499cb7ceab3", null ],
    [ "screenDist_", "df/d9b/classscg_1_1_stereo_camera.html#aec2804968bd1550355bce6369e0f30d4", null ],
    [ "screenHalfHeight_", "df/d9b/classscg_1_1_stereo_camera.html#a273781529d5088b47f10a07303a582c7", null ],
    [ "screenHalfWidth_", "df/d9b/classscg_1_1_stereo_camera.html#a094d94eb265f9a002473e844f6cd9f72", null ]
];