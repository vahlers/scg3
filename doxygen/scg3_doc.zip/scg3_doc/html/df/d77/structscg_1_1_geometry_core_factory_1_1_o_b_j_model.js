var structscg_1_1_geometry_core_factory_1_1_o_b_j_model =
[
    [ "OBJModel", "df/d77/structscg_1_1_geometry_core_factory_1_1_o_b_j_model.html#a64632b6f31c9416f5c11d8ae573db49b", null ],
    [ "faces", "df/d77/structscg_1_1_geometry_core_factory_1_1_o_b_j_model.html#a5bfd0407570670265514713e6f337c07", null ],
    [ "normals", "df/d77/structscg_1_1_geometry_core_factory_1_1_o_b_j_model.html#af8a226883ba71820a91a11507339c2b3", null ],
    [ "nTriangles", "df/d77/structscg_1_1_geometry_core_factory_1_1_o_b_j_model.html#a3f50da6804db3bf5cedb310c2caf7fa2", null ],
    [ "nVertices", "df/d77/structscg_1_1_geometry_core_factory_1_1_o_b_j_model.html#abc1de9f305474521a59f3343caac2ff1", null ],
    [ "texCoords", "df/d77/structscg_1_1_geometry_core_factory_1_1_o_b_j_model.html#afb990c9195f05a8d85d2d0d3e6b47c4a", null ],
    [ "vertices", "df/d77/structscg_1_1_geometry_core_factory_1_1_o_b_j_model.html#a4bc686126acb2fbc57ff98db5f156ac9", null ]
];