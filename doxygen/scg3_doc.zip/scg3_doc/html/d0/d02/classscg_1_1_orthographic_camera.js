var classscg_1_1_orthographic_camera =
[
    [ "OrthographicCamera", "d0/d02/classscg_1_1_orthographic_camera.html#a1e744eb2794fa16ce16c5338282b7602", null ],
    [ "~OrthographicCamera", "d0/d02/classscg_1_1_orthographic_camera.html#a8420469463c1357add023413605b5359", null ],
    [ "create", "d0/d02/classscg_1_1_orthographic_camera.html#a9fb14914cc8c7507457f76a44b36760c", null ],
    [ "init", "d0/d02/classscg_1_1_orthographic_camera.html#a40e0b0be3eef7f8f117019a1dde3220b", null ],
    [ "updateProjection", "d0/d02/classscg_1_1_orthographic_camera.html#a4ed0b5b994a3f40f3cfbb01cf3ad3afd", null ],
    [ "bottom_", "d0/d02/classscg_1_1_orthographic_camera.html#ac3153a6cd3303c67adfcbeb75684bf9b", null ],
    [ "far_", "d0/d02/classscg_1_1_orthographic_camera.html#a947e03cfc7be07b29630da2b921b25b2", null ],
    [ "left_", "d0/d02/classscg_1_1_orthographic_camera.html#a9958ef41494e7f90d6a44dd275472ee4", null ],
    [ "near_", "d0/d02/classscg_1_1_orthographic_camera.html#a9b7ac36f1b41fc6def737ebdf7bbb833", null ],
    [ "right_", "d0/d02/classscg_1_1_orthographic_camera.html#ae6c93d88ab8b96078340e98f698d13ba", null ],
    [ "top_", "d0/d02/classscg_1_1_orthographic_camera.html#abfd7340edc1e9860ba34caa8d0da6e2a", null ]
];