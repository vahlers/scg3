var structscg_1_1_geometry_core_factory_1_1_face =
[
    [ "Face", "d0/d68/structscg_1_1_geometry_core_factory_1_1_face.html#af892b2e0c29a02f10f578a24dd130bdd", null ],
    [ "entries", "d0/d68/structscg_1_1_geometry_core_factory_1_1_face.html#a4cbf5cdbcdb435e2e2c66c1fed946bd4", null ],
    [ "nTriangles", "d0/d68/structscg_1_1_geometry_core_factory_1_1_face.html#ae43c4a72990817df5c52694b4ecc5e31", null ]
];