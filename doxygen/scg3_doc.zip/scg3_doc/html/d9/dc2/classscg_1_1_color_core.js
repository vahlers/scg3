var classscg_1_1_color_core =
[
    [ "ColorCore", "d9/dc2/classscg_1_1_color_core.html#a04c4ede77879db0698bb81fae7a26993", null ],
    [ "~ColorCore", "d9/dc2/classscg_1_1_color_core.html#a5fe4a7dbe698cc17c82d823b666bc971", null ],
    [ "create", "d9/dc2/classscg_1_1_color_core.html#a10445d3548fcdb887ad83b6b389fd064", null ],
    [ "render", "d9/dc2/classscg_1_1_color_core.html#a6e163aed5c4aad5a792c5dd8d17936ef", null ],
    [ "renderPost", "d9/dc2/classscg_1_1_color_core.html#a3cbb1fdb89718c3e31855f7179ec0fb3", null ],
    [ "setColor", "d9/dc2/classscg_1_1_color_core.html#a420719d09af5d31cffdfa7a1d561904f", null ],
    [ "setMatrix", "d9/dc2/classscg_1_1_color_core.html#a4d21d71da4ae059a7279506365306b40", null ],
    [ "color_", "d9/dc2/classscg_1_1_color_core.html#ad655198ff2e6e96a6ebaaa018145d93d", null ],
    [ "colorCoreOld_", "d9/dc2/classscg_1_1_color_core.html#a97bae386020b5b08a65c39db12df568e", null ],
    [ "isColorSet_", "d9/dc2/classscg_1_1_color_core.html#a6dd991cd508033a4ee49ffeca6bb2602", null ],
    [ "matrix_", "d9/dc2/classscg_1_1_color_core.html#a71a5e18c060a7281b61ffdb99f4e4246", null ]
];