var structscg_1_1_o_g_l_sampler =
[
    [ "name", "d9/d36/structscg_1_1_o_g_l_sampler.html#a090577f656431c556415025e78d000ce", null ],
    [ "texUnit", "d9/d36/structscg_1_1_o_g_l_sampler.html#ad022a8842c70f845da8540ec93f5780b", null ]
];