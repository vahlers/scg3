var toon__lighting_8glsl =
[
    [ "Light", "d7/d61/struct_light.html", "d7/d61/struct_light" ],
    [ "Material", "d3/d0a/struct_material.html", "d3/d0a/struct_material" ],
    [ "applyLighting", "d8/db7/toon__lighting_8glsl.html#ae8ca6d4e798b8b07ee4edb4125da1514", null ],
    [ "directionalLight", "d8/db7/toon__lighting_8glsl.html#a3075a76fa4cd3d2b8f33b6094f6eb075", null ],
    [ "layout", "d8/db7/toon__lighting_8glsl.html#a50f033ca1c07e51e1917c7b9eff9acaf", null ],
    [ "pointLight", "d8/db7/toon__lighting_8glsl.html#ab0954165aca0e2746a4688b0fb9a73aa", null ],
    [ "spotLight", "d8/db7/toon__lighting_8glsl.html#a794556fa8d18f4bd8928eddd77b1e107", null ],
    [ "globalAmbientLight", "d8/db7/toon__lighting_8glsl.html#aa7bbb16f764a18c19e8b541d163e0745", null ],
    [ "MAX_NUMBER_OF_LIGHTS", "d8/db7/toon__lighting_8glsl.html#a37b1f22d3695f43409926ca1c960f1fe", null ],
    [ "nLights", "d8/db7/toon__lighting_8glsl.html#a322d434fbb6f95c69bb1bdb8dfc18faa", null ]
];