var classscg_1_1_stereo_renderer_passive =
[
    [ "StereoRendererPassive", "d8/d0f/classscg_1_1_stereo_renderer_passive.html#a60637a1a6ee18999ea784021f7f4381d", null ],
    [ "~StereoRendererPassive", "d8/d0f/classscg_1_1_stereo_renderer_passive.html#abb972ad6fc82ad4c2e010c74a130454b", null ],
    [ "create", "d8/d0f/classscg_1_1_stereo_renderer_passive.html#a838b93ba6ec9656a60699986202b0236", null ],
    [ "render", "d8/d0f/classscg_1_1_stereo_renderer_passive.html#aaaedf604295d1b68cae2eb139b57a405", null ]
];