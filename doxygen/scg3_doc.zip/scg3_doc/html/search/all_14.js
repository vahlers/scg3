var searchData=
[
  ['window_5f',['window_',['../d1/db0/classscg_1_1_viewer.html#ac41523c5510cff694a43748e48ab4877',1,'scg::Viewer::window_()'],['../d3/dde/classscg_1_1_view_state.html#a793e12b7e3c858452b8389e41208699d',1,'scg::ViewState::window_()']]]
];
