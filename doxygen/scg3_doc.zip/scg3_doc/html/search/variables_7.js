var searchData=
[
  ['half_5fvector_5foffset',['HALF_VECTOR_OFFSET',['../da/d81/classscg_1_1_light.html#a792bd07d9f42b5ea67e05b8a4afa97b5',1,'scg::Light']]]
];
