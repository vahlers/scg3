var searchData=
[
  ['global_5fambient_5flight',['GLOBAL_AMBIENT_LIGHT',['../de/dfc/classscg_1_1_o_g_l_constants.html#adb66ef113e22013da6191bae15e3340c',1,'scg::OGLConstants']]],
  ['globalambientlight_5f',['globalAmbientLight_',['../db/dfa/classscg_1_1_render_state.html#a6432cb4f60eb4d4ff67b08e83265f059',1,'scg::RenderState']]],
  ['greenbits',['greenbits',['../db/d02/structscg_1_1_frame_buffer_size.html#a806e187d736e2af2f144b2fa891b8b62',1,'scg::FrameBufferSize']]]
];
