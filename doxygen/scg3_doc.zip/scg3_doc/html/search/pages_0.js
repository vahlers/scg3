var searchData=
[
  ['scg3_3a_20an_20opengl_203_20_2f_20c_2b_2b11_20scene_20graph_20library_20for_20teaching_20computer_20science',['scg3: An OpenGL 3 / C++11 Scene Graph Library for Teaching Computer Science',['../index.html',1,'']]]
];
