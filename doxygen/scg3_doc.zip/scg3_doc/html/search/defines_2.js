var searchData=
[
  ['scg_5fdeclare_5fclass',['SCG_DECLARE_CLASS',['../d9/de0/scg__internals_8h.html#a210fffe9ab3017a81517c00cd470a481',1,'scg_internals.h']]],
  ['scg_5fdisallow_5fcopy_5fand_5fassign',['SCG_DISALLOW_COPY_AND_ASSIGN',['../d9/de0/scg__internals_8h.html#a55bab572d72d37efed8562c53039bf48',1,'scg_internals.h']]],
  ['scg_5fdoxygen_5fstub',['SCG_DOXYGEN_STUB',['../d9/d3c/scg__doxygen__stub_8h.html#a1b088c9b4663a888eaf2c59b1f61321e',1,'scg_doxygen_stub.h']]],
  ['scg_5frestore_5fprogram',['SCG_RESTORE_PROGRAM',['../d9/de0/scg__internals_8h.html#aa71670f5308a4fb9ead7afbcfe518121',1,'scg_internals.h']]],
  ['scg_5fsave_5fand_5fswitch_5fprogram',['SCG_SAVE_AND_SWITCH_PROGRAM',['../d9/de0/scg__internals_8h.html#ac43b213d37a8792be744d95819e83054',1,'scg_internals.h']]]
];
