var searchData=
[
  ['objmodel',['OBJModel',['../df/d77/structscg_1_1_geometry_core_factory_1_1_o_b_j_model.html#a64632b6f31c9416f5c11d8ae573db49b',1,'scg::GeometryCoreFactory::OBJModel']]],
  ['oglconfig',['OGLConfig',['../d7/d72/structscg_1_1_o_g_l_config.html#ab426b0e51224e43f75530c8361f85cd2',1,'scg::OGLConfig::OGLConfig()'],['../d7/d72/structscg_1_1_o_g_l_config.html#a8c81983260c3e8332aefc166ca25a4d6',1,'scg::OGLConfig::OGLConfig(int versionMajor0, int versionMinor0, GLboolean forwardCompatible0, OGLProfile profile0, glm::vec4 clearColor0)']]],
  ['orthographiccamera',['OrthographicCamera',['../d0/d02/classscg_1_1_orthographic_camera.html#a1e744eb2794fa16ce16c5338282b7602',1,'scg::OrthographicCamera']]]
];
