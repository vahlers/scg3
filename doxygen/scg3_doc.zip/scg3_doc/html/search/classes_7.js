var searchData=
[
  ['leaf',['Leaf',['../d7/dc9/classscg_1_1_leaf.html',1,'scg']]],
  ['light',['Light',['../da/d81/classscg_1_1_light.html',1,'scg']]],
  ['lightposition',['LightPosition',['../d7/da7/classscg_1_1_light_position.html',1,'scg']]]
];
