var searchData=
[
  ['n_5flights',['N_LIGHTS',['../de/dfc/classscg_1_1_o_g_l_constants.html#a828e9b24c46bb4d48cfa1af109587a51',1,'scg::OGLConstants']]],
  ['name',['name',['../d4/d10/structscg_1_1_o_g_l_attrib.html#aa086e7977ca1fd5b8d79281db96c204d',1,'scg::OGLAttrib::name()'],['../d1/d28/structscg_1_1_o_g_l_frag_data.html#a05960c994cac21364741f7737da1bbad',1,'scg::OGLFragData::name()'],['../d3/da9/structscg_1_1_o_g_l_uniform_block.html#a8af7497bc84a8c3118cd1955ac571821',1,'scg::OGLUniformBlock::name()'],['../d9/d36/structscg_1_1_o_g_l_sampler.html#a090577f656431c556415025e78d000ce',1,'scg::OGLSampler::name()'],['../d1/dad/structscg_1_1_shader_i_d.html#a3ee4f2d25bc558d498f99399181f5b93',1,'scg::ShaderID::name()']]],
  ['ncores_5f',['nCores_',['../db/d76/classscg_1_1_info_traverser.html#ab35196305aa4cabef764d026a2da5e70',1,'scg::InfoTraverser']]],
  ['near_5f',['near_',['../d0/d02/classscg_1_1_orthographic_camera.html#a9b7ac36f1b41fc6def737ebdf7bbb833',1,'scg::OrthographicCamera::near_()'],['../d2/d30/classscg_1_1_perspective_camera.html#ac9d08d1434ae8568252c212d604b4027',1,'scg::PerspectiveCamera::near_()'],['../df/d9b/classscg_1_1_stereo_camera.html#a7685c9ebd0118b11bbf1d499cb7ceab3',1,'scg::StereoCamera::near_()']]],
  ['nelements_5f',['nElements_',['../d7/d13/classscg_1_1_geometry_core.html#ac6dc1ac0ae4bdffb47eb9b4834ee3c04',1,'scg::GeometryCore']]],
  ['nlights_5f',['nLights_',['../db/dfa/classscg_1_1_render_state.html#a10f679f7dde93bfbd8b11853351742c1',1,'scg::RenderState']]],
  ['nnodes_5f',['nNodes_',['../db/d76/classscg_1_1_info_traverser.html#aa4d9a825b5a07cca462b5eefe7f65b4f',1,'scg::InfoTraverser']]],
  ['normal',['normal',['../d4/dee/structscg_1_1_geometry_core_factory_1_1_face_entry.html#a8d94b52eecb772a87403959fa57a2458',1,'scg::GeometryCoreFactory::FaceEntry::normal()'],['../de/dfc/classscg_1_1_o_g_l_constants.html#a8e791c72c8f2fb7160b3c91e37342cae',1,'scg::OGLConstants::NORMAL()']]],
  ['normal_5fmatrix',['NORMAL_MATRIX',['../de/dfc/classscg_1_1_o_g_l_constants.html#a9232bb2e3b80ba040dacb2ef326d1164',1,'scg::OGLConstants']]],
  ['normals',['normals',['../df/d77/structscg_1_1_geometry_core_factory_1_1_o_b_j_model.html#af8a226883ba71820a91a11507339c2b3',1,'scg::GeometryCoreFactory::OBJModel']]],
  ['ntriangles',['nTriangles',['../d0/d68/structscg_1_1_geometry_core_factory_1_1_face.html#ae43c4a72990817df5c52694b4ecc5e31',1,'scg::GeometryCoreFactory::Face::nTriangles()'],['../df/d77/structscg_1_1_geometry_core_factory_1_1_o_b_j_model.html#a3f50da6804db3bf5cedb310c2caf7fa2',1,'scg::GeometryCoreFactory::OBJModel::nTriangles()']]],
  ['ntriangles_5f',['nTriangles_',['../db/d76/classscg_1_1_info_traverser.html#a9874f36e882e4c67d5a4da68dbafe9a4',1,'scg::InfoTraverser']]],
  ['nvertices',['nVertices',['../df/d77/structscg_1_1_geometry_core_factory_1_1_o_b_j_model.html#abc1de9f305474521a59f3343caac2ff1',1,'scg::GeometryCoreFactory::OBJModel']]]
];
