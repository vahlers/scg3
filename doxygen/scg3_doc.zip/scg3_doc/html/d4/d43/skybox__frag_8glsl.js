var skybox__frag_8glsl =
[
    [ "main", "d4/d43/skybox__frag_8glsl.html#acdef7a1fd863a6d3770c1268cb06add3", null ],
    [ "colorMatrix", "d4/d43/skybox__frag_8glsl.html#ac75ede864f85be96eaa94ce0be32ee9f", null ],
    [ "fragColor", "d4/d43/skybox__frag_8glsl.html#a6d8dd0540ed9af35f34cd31b838cacce", null ],
    [ "texCoord0", "d4/d43/skybox__frag_8glsl.html#ac3adbfdd35a0cebae117f3eb7423ffdb", null ],
    [ "texture0", "d4/d43/skybox__frag_8glsl.html#a75e6a729fd47b4ae100ce30d4e4a2118", null ]
];