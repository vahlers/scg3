var structscg_1_1_o_g_l_attrib =
[
    [ "location", "d4/d10/structscg_1_1_o_g_l_attrib.html#aafe75e2a3d9079b1d0bdf4a2e93b0e11", null ],
    [ "name", "d4/d10/structscg_1_1_o_g_l_attrib.html#aa086e7977ca1fd5b8d79281db96c204d", null ]
];