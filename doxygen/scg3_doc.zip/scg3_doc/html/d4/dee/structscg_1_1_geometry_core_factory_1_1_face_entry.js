var structscg_1_1_geometry_core_factory_1_1_face_entry =
[
    [ "FaceEntry", "d4/dee/structscg_1_1_geometry_core_factory_1_1_face_entry.html#a247091e1ccb3f874c0b6bf1ab12685ed", null ],
    [ "normal", "d4/dee/structscg_1_1_geometry_core_factory_1_1_face_entry.html#a8d94b52eecb772a87403959fa57a2458", null ],
    [ "texCoord", "d4/dee/structscg_1_1_geometry_core_factory_1_1_face_entry.html#a6a65b7fa192b3f99dd26291461d5271c", null ],
    [ "vertex", "d4/dee/structscg_1_1_geometry_core_factory_1_1_face_entry.html#af872c5e3731fae1d4c7d4e16afa3ac41", null ]
];