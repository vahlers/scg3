var simple__flat__frag_8glsl =
[
    [ "main", "d4/d77/simple__flat__frag_8glsl.html#a6288eba0f8e8ad3ab1544ad731eb7667", null ],
    [ "color", "d4/d77/simple__flat__frag_8glsl.html#aafdd6c6602e767e0fdbc04609b06f750", null ],
    [ "fragColor", "d4/d77/simple__flat__frag_8glsl.html#a6d8dd0540ed9af35f34cd31b838cacce", null ]
];