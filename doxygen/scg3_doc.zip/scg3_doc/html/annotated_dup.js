var annotated_dup =
[
    [ "scg", "d7/d60/namespacescg.html", "d7/d60/namespacescg" ]
];